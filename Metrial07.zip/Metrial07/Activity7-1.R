##########################################
#ACTIVITY 7-1 TOY PROBLEM WITH NN
##########################################

library("neuralnet")

x1 = c(1,0,1,0,0,1,1,0)
x2 = c(0,0,1,0,0,1,1,0)
y = c(1,1,0,0,1,1,0,0)
datatrain = data.frame(x1,x2,y)
datatrain

model <- neuralnet( y~x1+x2, 
	datatrain, 
	hidden=10, ##<--Change here
	rep = 1,
	linear.output = TRUE)
print(model)
plot(model)
print(model$net.result)


##########################################
clear_all_plot = function()
{
	w = dev.cur()
	for(i in 1:w)
	{
		dev.off()
	}
}
#clear_all_plot()