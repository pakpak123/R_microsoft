
library("neuralnet")
rm(list = ls())

radius = 1:4
height = 1:4
volume = pi*radius*radius*height
surface = 2*pi*radius*height
datatrain = data.frame(radius,height,volume,surface)
datatrain
model <- neuralnet(volume+surface~radius+height,
    datatrain,
    hidden=3, ##<--Change here
    rep = 1,
    linear.output = TRUE)
print(model)
plot(model)
print(model$net.result)

testdata = data.frame(radius,height)
pred_result = predict(model,testdata) 
print(pred_result)


#CREATE MY NEURAL NETWORK
w = model$weights
test_radius = testdata$radius[4]
test_height = testdata$height[4] 
#input --> xh --> ho --output
xh = w[[1]][1]
xh = xh[[1]]
ho = w[[1]][2]
ho = ho[[1]]

print(xh)
print(ho)

# The xh[1, ] are the bias.
# The xh[2..end, ] are the inputs.
# The ho[1, ] are the bias.
# The ho[2..end, ] are the outputs.

# The calculation uses input x multiple by xh as the neural equation below.
#    x[1] --- xh[1,i]  \
#    x[2] --- xh[2,i]  x[1]*wh[1,i] + x[2]*wh[2,i] + x[3]*wh[3,i] = h[H]
#    x[3] --- xh[3,1] /


#get dimension in xh
MaxRow = dim(xh)[1]
MaxCol = dim(xh)[2]

x = c(1,test_radius,test_height)
hbar = x*xh
print(hbar)
h = 1:MaxCol
for(i in 1:MaxCol)
{
    h[i] = sum(hbar[,i])
}
print(h)
h = actfunc(h)
#the output part similar to the input part mentioned above. 
# The calculation uses input x multiple by xh as the neural equation below.
#   h[1] --- ho[1,i]  \
#   h[2] --- ho[2,i]  h[1]*ho[1,i] + h[2]*ho[2,i] + h[3]*ho[3,i] = o[H]
#   h[3] --- ho[3,1] /

hbar = h
hbar = c(1,h)

print(hbar)
print(ho)
obar = hbar*ho
print(obar)

MaxRow = dim(ho)[1]
MaxCol = dim(ho)[2]

o = 1:MaxCol
for(i in 1:MaxCol)
{
    o[i] = sum(obar[,i])
}
print("NN OUTPUT IS")
print(o)
sum(o)


actfunc = function (x) 
{
    1/(1 + exp(-x))
}
