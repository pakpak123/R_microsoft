a = c(1,2,3,4,5,6)
ma = matrix(a,ncol=3)
print(ma)
ma = matrix(a,ncol=3,bycolumn=TRUE)
print(ma)
b = c(7,8,9,10,11,12)
mb = matrix(b,ncol=2,bycolumn=TRUE)
print(mb)
mc = ma*mb #Error non-conformable arrays
mc = ma%*%mb
print(mc)
mymul(ma,mb)
//////////////////////////
  rm(list=ls())
library("neuralnet")
x1 = c(1,0,1,0,0,1,1,0)
x2 = c(0,0,1,0,0,1,1,0)
y = c(1,1,0,0,1,1,0,0)
datatrain = data.frame(x1,x2,y)

model = neuralnet(y ~ x1+x2,
                  datatrain,
                  hidden=8,
                  rep=1,
                  linear.output = FALSE)

print(model)
plot(model)

#PREDICTION
x1 = c(0,1,0,1)
x2 = c(0,0,1,1)
input = data.frame(x1,x2)
pred = predict(model,input)
pred

#RNN Cell
create_matrix_rand_val = function(nr,nc)
{
  #vr = runif(nr*nc)
  vr = rnorm(nr*nc)
  mr = matrix(vr, ncol=nc) 
  return(mr)
}
set.seed(1)
xt = create_matrix_rand_val(3,10) #input data at timestep t
a_prev = create_matrix_rand_val(5,10) #Hidden state at timestep
t-1
Wax = create_matrix_rand_val(5,3) #Weight matrix the input
Waa = create_matrix_rand_val(5,5) #Weight matrix the input
Wya = create_matrix_rand_val(2,5) #Weight matrix the hidden
ba = create_matrix_rand_val(5,1) #Bias
by = create_matrix_rand_val(2,1) #Bias relating the hidden
W_a = Waa %*% a_prev
W_x = Wax %*% xt
W_aW_xby = rowSums(W_a + W_x) + ba
a_next = tanh(W_aW_xby)
Wya_anext = Wya %*% a_next
library(sigmoid)
yt_pred = SoftMax(Wya_anext+by)
print(a_next)
print(yt_pred)
