###################################################
# ACTIVITY 6.2 
# SCEALING AUTO DATASET
###################################################
library("neuralnet")

#LOAD AUTO LIBRARY
#install.packages("ISLR")
library("ISLR")
data = Auto

#OPEN DATA DIALOG FOR CHECKING
View(data)	

color = c("red","green")
par(mfrow=c(2,2))
plot(data$weight, data$mpg, pch=data$origin,cex=2,col=color)
plot(data$cylinders, data$mpg, pch=data$origin,cex=1,col=color)
plot(data$displacement, data$mpg, pch=data$origin,cex=1,col=color)
plot(data$horsepower, data$mpg, pch=data$origin,cex=1,col=color)
###################################################


#plot(data$acceleration, data$mpg, pch=data$origin,cex=1)

#DATA SCALING
mean_data = apply(data[1:6], 2, mean)
sd_data = apply(data[1:6], 2, sd)
head(data[1:6])
head(mean_data)

data_scaled = as.data.frame(scale(data[,1:6],
   center = mean_data, scale = sd_data))
head(data_scaled)

head(data_scaled, n=20)

#MAKE INDEX FOR SAMPLING 70% FOR TRAINING
index = sample(1:nrow(data),round(0.70*nrow(data)))

#PLACE THE SAMPLING TO TRAIN/TEST SET
train_data = as.data.frame(data_scaled[index,])

test_data = as.data.frame(data_scaled[-index,])
###################################################


#CREATE STRING MESSAGE FOR TRAINING
n = names(data_scaled)
f = as.formula(paste("mpg ~", paste(n[!n %in% "mpg"], 
   collapse = " + ")))

#TRAINING
net = neuralnet(f,data=train_data,hidden=3,linear.output=TRUE)

#PLOT MODEL
plot(net)
###################################################

predict_net_test <- compute(net,test_data[,2:6])
MSE.net <- sum((test_data$mpg - predict_net_test$net.result)^2)/nrow(test_data)
MSE.net

plot(test_data$mpg,
	predict_net_test$net.result,col='blue',
	main='Real vs Predicted',pch=21,cex=4)

abline(0,1,lwd=5)
###################################################


