##########################################
ACTIVITY 6-1 70/30 IRIS DATASET ON NEURALNET
##########################################

#PREPARING DATA
data(iris)
head(iris)	#CHECK COLUMN NAME
#Sepal.Length Sepal.Width Petal.Length Petal.Width Species

#CHEANGING setosa=1, versicolor=2, virginica=3
alldata = data.frame(iris)
alldata$Species = c(rep(1,50),rep(2,50),rep(3,50))
#alldata

#DIVIDING 70/30 
index = sample(1:nrow(alldata), round(0.7*nrow(alldata)))
datatrain = as.data.frame(alldata[index,])
datatest = as.data.frame(alldata[-index,])	#DELETE ONLY INDEX	
nrow(datatrain)	#NUMBER OF ROW
nrow(datatest)

#TRAINING 
library("neuralnet")
model <- neuralnet( Species~Sepal.Length+Sepal.Width+Petal.Length+Petal.Width, 
	datatrain, 
	hidden=5, ##<--Change here
	rep = 1,
	linear.output = TRUE)
print(model)
plot(model)
print(model$net.result)

#TESTING
predictions <- predict(model,datatest)
datatest[,6] = predictions
datatest

##########################################
#PLOT RESULT
ydata = cbind(datatest$Species,datatest$V6)
x = 1:nrow(datatest$V6)
plot(datatest$Species)

##########################################
clear_all_plot = function()
{
	w = dev.cur()
	for(i in 1:w)
	{
		dev.off()
	}
}
#clear_all_plot()