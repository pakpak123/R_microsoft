##################################################
## Activity 8.5 Changing data train in weatherAUS
## Prediction rainfall with data from  WindGuestSpeed 
## and Humidity9am
##################################################

library("rattle.data")
library("rnn")
library("data.table")

# Standardize in the interval 0 - 1
std0to1 = function(v)
{
        r= (v - min(v)) / (max(v) - min(v))
        return(r)
}


data(weatherAUS)
#View(weatherAUS)


setDTthreads(3)
names(weatherAUS)#show list of data name
#[1] "Date"          "Location"      "MinTemp"       "MaxTemp"      
#[5] "Rainfall"      "Evaporation"   "Sunshine"      "WindGustDir"  
#[9] "WindGustSpeed" "WindDir9am"    "WindDir3pm"    "WindSpeed9am" 
#[13] "WindSpeed3pm"  "Humidity9am"   "Humidity3pm"   "Pressure9am"  
#[17] "Pressure3pm"   "Cloud9am"      "Cloud3pm"      "Temp9am"      
#[21] "Temp3pm"       "RainToday"     "RISK_MM"       "RainTomorrow" 

#target = Rainfall, data = WindGuestSpeed+Humidity9am
data=weatherAUS[1:400,c(4,9,14)]
summary(data)

data_cleaned = na.omit(data) 

y = data_cleaned[1:300,1]
x1 = data_cleaned[1:300,2]
x2 = data_cleaned[1:300,3]


#convert data from the large range to 0..1
y = std0to1(y)
x1 = std0to1(x1)
x2 = std0to1(x2)


#the sequence length 300 obs,so it was divided to 10 parts (30obs per each)
tim = 10
sam = length(x1)/tim
X1 = array(x1,c(sam,tim))
X2 = array(x2,c(sam,tim))
Y =  array(yx,c(sam,tim))


# create 3d array: dim 1: samples; dim 2: time; dim 3: variables
Xt <- array( c(X1,X2), dim=c(dim(X1),2) )
Yt <- array( c(Y,Y), dim=c(dim(Y),2) )
dim(Xt);dim(Yt) 
#You should make sure that Xt and Yt are 3D 
#This case has 30,10,2 dim by 
#       30 means 30 observations (it was divided from the previous part)
#       10 means 10 sequence (rnn realates to the time).
#       2 for Xt and 1 for Yt is number of input data.
#####################################
#####################################

maxiter = 100

model <- trainr(Y = Yt,
                X = Xt,
                learningrate = 0.01,
                hidden_dim = 200,
                numepochs = maxiter)



par(mfrow=c(2,1))
plot(colMeans(model$error[,1:maxiter]),type='l',xlab='Epoch'
     ,ylab='Errors')
Yp = predictr(model, Yt)
plot(as.vector(Yp), col = 'red', type='l', 
     main = "Actual vs Predicted on Training Data Set", 
     ylab = "Y,Yp")
lines(as.vector(Yt), type = 'l', col = 'black')
#legend("bottomright", c("Predicted", "Actual"), col = c("red","black"), lty = c(1,1), lwd = c(1,1))

