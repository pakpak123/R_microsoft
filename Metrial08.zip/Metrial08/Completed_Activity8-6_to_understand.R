#################################################
# Activity 8.6 To understand 3D dimension on rnn
# Modify by supakit@it.kmitl.ac.th
#################################################

x1 = 1:(5*4*3) #1000 8 2
x2 = 101:(100+5*4*3)
y  = 201:(200+5*4*3)

mx1 =  matrix(x1,ncol=4)
mx2 =  matrix(x2,ncol=4) 
my =   matrix(y,ncol=4) 

X <- array( c(mx1,mx2), dim=c(dim(mx1),2) )
Y <- array( c(my), dim=c(dim(my),1) )    #Is it should be 1 or 2
dim(X)
X
dim(Y)
Y

Xt = X/261
Yt = Y/261

model = trainr(Y=Yt,
               X=Xt,
               learningrate   =  0.1,
               hidden_dim     = 100,
               numepochs = 100)



Yp = predictr(model, Xt)

par(mfrow=c(2,1))
plot(colMeans(model$error[,1:maxiter]),type='l',xlab='Epoch',ylab='Errors')
plot(as.vector(Yp), col = 'red', type='l', 
     main = "Actual vs Predicted on Training Data Set", 
     ylab = "Yt,Yp")
lines(as.vector(Yt), type = 'l', col = 'black')
