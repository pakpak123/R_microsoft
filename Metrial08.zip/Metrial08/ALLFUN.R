

##########################################
clear_all_plot = function()
{
	w = dev.cur()
	for(i in 1:w)
	{
		dev.off()
	}
}
#clear_all_plot()