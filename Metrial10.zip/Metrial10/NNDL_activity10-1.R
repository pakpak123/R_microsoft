###################################################
## ACTIVITY 10.1 CNN WITH NEURAL PROGRAMMABLE FILTER
##################################################

#install.packages("neuralnet")
rm(list=ls())
library("neuralnet")


##########################################
##########################################
###########################################
neural_fiter.create = function(k,o)
{
  o = o; k1 = k[1];k2 = k[2];k3 = k[3];k4 = k[4];
  k5 = k[5];k6 = k[6];k7 = k[7];k8 = k[8];k9 = k[9];
  datatrain = data.frame(k1,k2,k3,k4,k5,k6,k7,k8,k9,o)
  datatrain
  
  model <- neuralnet( o~k1+k2+k3+k4+k5+k6+k7+k8+k9, 
                      datatrain, 
                      hidden=5, ##<--Change here
                      rep = 1,
                      linear.output = FALSE,
                      stepmax = 1000)
  print(model)
  plot(model)
  print(model$net.result)
  return(model)
}

neural_fiter.measure = function(k,model)
{
  k1 = k[1];k2 = k[2];k3 = k[3];k4 = k[4];
  k5 = k[5];k6 = k[6];k7 = k[7];k8 = k[8];k9 = k[9];
  datatest = data.frame(k1,k2,k3,k4,k5,k6,k7,k8,k9)
  pred <- predict(model, datatest)
  #print(pred)
  return(pred)
}

##Testfunction#############################
m = neural_fiter.create(c(1,0,1,0,1,0,1,0,1),1)
r = neural_fiter.measure(c(1,0,1,0,1,0,1,0,1),m)
##########################################
##########################################
##########################################


##Create filter model#######################
fp1 = c(0,0,1,
        0,1,0,
        1,0,0)
filterM1 = neural_fiter.create(fp1,1)
fp2 = c(1,0,0,
        0,1,0,
        0,0,1)
filterM2 = neural_fiter.create(fp2,1)

r = neural_fiter.measure(fp1,filterM1)
r = neural_fiter.measure(fp2,filterM2)
r = neural_fiter.measure(fp2,filterM1)
r = neural_fiter.measure(fp1,filterM2)


##########################################
##########################################
##########################################
##########################################


img = c(4,9,2,5,8,3,
        5,6,2,4,0,3,
        2,4,5,4,5,2,
        5,6,5,4,7,8,
        5,7,7,9,2,1,
        5,8,5,3,8,4)


img = matrix(img,nrow = 6, byrow=TRUE)
img


#APPLY FEATURE TO IMAGE INPUT
mulresult = rep(NA,1)
c = 1
print(img)
for (j in 1:4)
{
    m = j+2
    for (i in 1:4)
    {
        k =i+2
        #str = sprintf("%d:%d / %d:%d",j,m,i,k)
        #print(str)
        #print(img[j:m,i:k])
        partimg = img[j:m,i:k]
        k = as.vector(partimg)
        f1 = neural_fiter.measure(k,filterM1)
        f2 = neural_fiter.measure(k,filterM2)
        str = sprintf("F1 = %f, F2= %f",f1,f2)
        print(str)
        #mulfilter = partimg * feamatrix
        #mulresult[c] = sum(mulfilter)    
        #print(mulfilter)
        c = c+1
    }
    print("======")
}



            